"""Minimal offline regression tests."""
