"""Prompt and LLM construction."""
