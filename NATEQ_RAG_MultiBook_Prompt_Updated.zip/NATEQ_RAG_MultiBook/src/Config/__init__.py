"""Pipeline configuration."""
