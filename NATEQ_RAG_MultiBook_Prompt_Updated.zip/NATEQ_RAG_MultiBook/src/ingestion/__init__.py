"""Source ingestion and chunking."""
